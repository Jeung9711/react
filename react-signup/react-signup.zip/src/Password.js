import { useEffect, useState } from "react";

function Password({ formData, setFormData }) {
  const [pass,setPass] = useState('');
  const [passCheck, setPassCheck] = useState('');
  const [match, setMatch] = useState(false);

  useEffect(() => {
    //console.log(`pass= ${pass} passCheck= ${passCheck}`)
    if (pass == passCheck){
        setMatch(true);
        setFormData((prevformData) => ({...prevformData, password: pass}));
      } else {
        setMatch(false)
      }
  },[pass,passCheck, setFormData]);


    return(
        <div>
          <div className="form-group">
            <label htmlFor="password">비밀번호</label>
            <input
              type="password"
              id="password"
              name="password"
              value={pass}
              onChange={(e) => {setPass(e.target.value)}}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="confirmPassword">비밀번호 확인</label>
            <input
              type="password"
              id="confirmPassword"
              name="confirmPassword"
              value={passCheck}
              onChange={(e) => {setPassCheck(e.target.value)}}
              required
            />

            {match==true?
            null
            :<label id="pw-match" className="pw-match" >비밀번호가 일치해야 됩니다.</label>
            }
          </div>
        </div>
    );
}

export default Password;