import { useState } from 'react';
import Checkbox from './Checkbox';
import Data from './Data';

function Formgroup({ formData, setFormData }) {
    const [check, setCheck] = useState(false);

    const change_check = (e) => {
        setCheck((v) => !v);
    };

    return(
        <form>
            <Checkbox check={check} onChange={change_check}></Checkbox>
            <Data check={check} formData={formData} setFormData={setFormData}></Data>
        </form>
    );
}

export default Formgroup;